import test, { expect } from "@playwright/test";

test('Create new user in gorest server',async({request})=>{
const response=await request.post('https://gorest.in/public/v2/users',{
    headers:{
        'Accept':'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer a894f1e9fc8c3ebb462e54a3416f321af0453901ca1379162b71922b7d9d8633'
    },
    data:{
        "name":"Naveen Kumar",
        "email":"nk@test.com",
        "gender":"male",
        "status":"active"
    }
})
expect(response.status()).toBe(201)
expect(response.statusText()).toBe('Created')
console.log(response.status())
console.log(response.statusText())
const newuser= await response.json()
const userid= newuser.id
const emailid= newuser.email
console.log(`Created User with ID: ${userid}`)
console.log(`Created User with ID: ${emailid}`)
console.log('-----------------------------------------')
console.log(newuser)
})